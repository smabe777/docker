import os

from flask import Flask, has_request_context
from flask.logging import default_handler
from flask import (Blueprint, flash, current_app, g, session, redirect, render_template, request, url_for, make_response, send_file, send_from_directory)

from datetime import timedelta

import logging

from logging.config import dictConfig

def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.config['SECRET_KEY'] = os.urandom(12).hex() 
    app.config['DATABASE'] = os.path.join(os.getcwd(),'instance','skillmgr.sqlite')
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    
    from skillmgr import db
    db.init_app(app)
    
    from . import auth
    app.register_blueprint(auth.bp)
    
    from skillmgr.controller.controller import(bp_auth, bp_skill)
    app.register_blueprint(bp_skill)
    app.add_url_rule('/', endpoint='index')
    
    # a simple page that says hello
    @app.route('/hello')
    def hello():
        return 'Hello, World!'
    
    return app