import functools

from flask import current_app

from . import config 

from flask import (Blueprint, flash, current_app, g, session, redirect, render_template, request, url_for, make_response, send_file, send_from_directory)

from werkzeug.security import check_password_hash, generate_password_hash

from skillmgr.db import get_db

bp = Blueprint('auth', __name__, url_prefix='/auth')

@bp.route('/login', methods=('GET','POST'))
def login():
    people = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        return redirect (url_for('index'))
    else:
        db=get_db()
        squads = db.execute ("SELECT DISTINCT Squad from People WHERE Active = 'YES'").fetchall()
        people = db.execute ("SELECT Name, Squad FROM People WHERE Active = 'YES'").fetchall()
    return render_template('auth/login.html', people=people, squads=squads)

@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')

    if user_id is None:
        g.user = 'admin'
    else:
        g.user = get_db().execute(
            'SELECT * FROM user WHERE id = ?', (user_id,)
        ).fetchone()
        
def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))

        return view(**kwargs)

    return wrapped_view