import sys
import os
import json
import sqlite3

from flask import (Blueprint, flash, current_app, g, session, redirect,
                   render_template, request, url_for, make_response, send_file, send_from_directory)

from skillmgr.auth import login_required
from skillmgr.db import get_db

bp_skill = Blueprint('skill-controller', __name__)
bp_auth = Blueprint('auth-controller', __name__)


@bp_skill.route('/')
@login_required
def index():
    db = get_db()
    print('I am here')
    skills = db.execute('SELECT us.[Skill Id], Skill, substr(Last_Update, 0, 11) as Last_Update, Team, Revision, Level, Dimension'
                        ' FROM user_skills us JOIN skills s ON us.[Skill Id] = s.[Skill Id] ').fetchall()
    for skill in skills:
        print(skill['Skill Id'])
    return render_template('skill/index.html', skills=skills)


@bp_skill.route('/add/<skillid>')
@login_required
def add(skillid):
    db = get_db()
    skill_field = f"Field_{skillid}"
    skill_group = f"Group_{skillid}"
    skill = f"{skillid}-Skill"
    print('add')
    try:
        db.execute('INSERT INTO skills ([Skill Id], [Skill], [Skill Field], [Skill Group]) VALUES '
                   ' (? , ?, ?, ?)', (skillid, skill, skill_field, skill_group))
        db.commit()
    except:
        pass
    import random
    level = random.randrange(1, 4)
    try:
        db.execute("insert into user_skills ([Skill Id], Level, User, Team, Revision) values (?, ?, 'admin','FUN','0')",
                   (skillid, level))
        db.commit()
    except:
        db.execute("update user_skills SET Level = ? WHERE [Skill Id] = ?",
                   (level, skillid))
        db.commit()

    return redirect(url_for('index'))

@bp_skill.route('/info')
@login_required
def info():
    return {
            'exists':os.path.exists(os.path.join(os.getcwd(),'instance','skillmgr.sqlite')),
            'ss' : os.path.join(os.getcwd(),'instance','skillmgr.sqlite'),
    }

@bp_skill.route('/download')
@login_required
def download():
    import os
    print(os.getcwd())
    return send_from_directory(os.path.join(os.getcwd(), 'instance'), 'skillmgr.sqlite', as_attachment=True)

@bp_skill.route('/upload', methods=('GET', 'POST'))
@login_required
def upload():
    if request.method == 'POST':
        print(f"request.files={request.files}")
        if request.files:
            file = request.files['file']
            file.save(os.path.join(os.getcwd(),'uploads',file.filename))
        else:
            return 'NO FILE REQUESTED'
        flash('done')
    else:
        return render_template ('skill/get_data.html')
    return render_template ('skill/index.html')
    

@bp_skill.route('/dir_listing', defaults={'req_path': ''})
@bp_skill.route('/dir_listing/<path:req_path>')
def dir_listing(req_path):
    BASE_DIR = '/skillmgr'

    # Joining the base and the requested path
    abs_path = os.path.join(BASE_DIR, req_path)

    # Return 404 if path doesn't exist
    if not os.path.exists(abs_path):
        return abort(404)

    # Check if path is a file and serve
    if os.path.isfile(abs_path):
        return send_file(abs_path)

    # Show directory contents
    files = os.listdir(abs_path)
    return render_template('skill/files.html', files=files)