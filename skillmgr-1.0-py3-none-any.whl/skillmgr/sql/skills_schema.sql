DROP TABLE IF EXISTS skills;


CREATE TABLE skills (
    "Skill Id" TEXT PRIMARY KEY,
    "Skill Group" TEXT NOT NULL,
    "Skill Field" TEXT NOT NULL,
    "Skill" TEXT NOT NULL,
    Dimension TEXT,
    Show BOOLEAN DEFAULT 1
);