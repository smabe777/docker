DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS user_skills;

CREATE TABLE user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE user_skills (
    "Skill Id" TEXT NOT NULL,
    Level TEXT,
    "User" TEXT NOT NULL,
    "Last_Update" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Team TEXT NOT NULL,
    Revision TEXT,
  FOREIGN KEY ("Skill Id") REFERENCES skills ("Skill Id")
);